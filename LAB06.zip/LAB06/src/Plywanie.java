public interface Plywanie {
    public void plyn();
    public void wynurz();
    public void zanurz();

}

