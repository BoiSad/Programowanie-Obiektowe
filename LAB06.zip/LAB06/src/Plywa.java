public interface Plywa {
    public void plyn();
}
interface Lata {
    public void lec();
}
class Statek implements Plywa {
    public void plyn(){
        System.out.println ("Statek plynie");
    }
}
class Samolot implements Lata {
    public void lec(){
        System.out.println ("Samolot leci");
    }
}
