public class Zwierze {
}
