public interface Latanie {
    public void plyn();
    public void lec();
}
