public class SrodkiTransportu {
    public static void main(String[] args) {

        Lata samolot = new Samolot();
        samolot.lec();

        Plywa statek = new Statek();
        statek.plyn();

    }
}
