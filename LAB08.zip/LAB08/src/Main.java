import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Konwerter extends JFrame implements ActionListener {
    private JLabel label;
    private JTextField textField;
    private JButton button;

    public Konwerter() {
        setLayout(new FlowLayout());

        label = new JLabel("Temperatura Celsius: ");
        add(label);

        textField = new JTextField(10);
        add(textField);

        button = new JButton("Konwert");
        add(button);
        button.addActionListener(this);

        setTitle("Konwerter");
        setSize(400, 100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent event) {
        double temperature, farenheit;
        String text = textField.getText();

        temperature = Double.parseDouble(text);
        farenheit = 9.0 / 5.0 * temperature + 32;

        JOptionPane.showMessageDialog(null, temperature + "°C = " + farenheit + "°F", "Result", JOptionPane.PLAIN_MESSAGE);
    }

    public static void main(String[] args) {
        Konwerter converter = new Konwerter();
    }
}