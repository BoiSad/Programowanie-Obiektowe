import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SumCalculator extends JFrame implements ActionListener {
    private JLabel label1, label2, resultLabel;
    private JTextField textField1, textField2, resultTextField;
    private JButton button;

    public SumCalculator() {
        setLayout(new FlowLayout());

        label1 = new JLabel("Podaj pierwsza liczbe: ");
        add(label1);

        textField1 = new JTextField(10);
        add(textField1);

        label2 = new JLabel("Podaj druga liczbe: ");
        add(label2);

        textField2 = new JTextField(10);
        add(textField2);

        button = new JButton("Oblicz");
        add(button);
        button.addActionListener(this);

        resultLabel = new JLabel("Sum: ");
        add(resultLabel);

        resultTextField = new JTextField(10);
        resultTextField.setEditable(false);
        add(resultTextField);

        setTitle("Sum Kalkulator");
        setSize(400, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent event) {
        double num1, num2, sum;
        String text1 = textField1.getText();
        String text2 = textField2.getText();

        num1 = Double.parseDouble(text1);
        num2 = Double.parseDouble(text2);
        sum = num1 + num2;

        resultTextField.setText(Double.toString(sum));
    }

    public static void main(String[] args) {
        SumCalculator calculator = new SumCalculator();
    }
}
